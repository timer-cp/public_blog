package com.ssm.po;

public class ItemsCustom extends Items{

	
	
}
