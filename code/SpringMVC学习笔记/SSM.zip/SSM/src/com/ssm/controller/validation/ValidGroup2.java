package com.ssm.controller.validation;

public interface ValidGroup2 {

}
