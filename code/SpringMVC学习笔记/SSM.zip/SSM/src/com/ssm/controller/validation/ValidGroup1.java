package com.ssm.controller.validation;

public interface ValidGroup1 {

}
