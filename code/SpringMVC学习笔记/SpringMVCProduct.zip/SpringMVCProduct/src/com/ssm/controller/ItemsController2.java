package com.ssm.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.HttpRequestHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.ssm.po.Items;

public class ItemsController2 implements HttpRequestHandler{

	@Override
	public void handleRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 创建静态数据
		List<Items> itemsList = new ArrayList<>();
		Items item1 = new Items();
		item1.setName("联想笔记本");
		item1.setPrice(6000f);
		item1.setDetail("ThinkPad T430 联想笔记本电脑");
		Items item2 = new Items();
		item2.setName("苹果手机");
		item2.setPrice(5000f);
		item2.setDetail("IPhone6 64G 黑色");
		itemsList.add(item1);
		itemsList.add(item2);
		// 设置模型数据
		request.setAttribute("itemsList",itemsList);
		// 设置转发的视图
		request.getRequestDispatcher("/WEB-INF/jsp/items/itemsList.jsp").forward(request, response);
	}
//	@Override
//	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
//		// 创建静态数据
//		List<Items> itemsList = new ArrayList<>();
//		Items item1 = new Items();
//		item1.setName("联想笔记本");
//		item1.setPrice(6000f);
//		item1.setDetail("ThinkPad T430 联想笔记本电脑");
//		Items item2 = new Items();
//		item2.setName("苹果手机");
//		item2.setPrice(5000f);
//		item2.setDetail("IPhone6 64G 黑色");
//		itemsList.add(item1);
//		itemsList.add(item2);
//		// 返回ModelAndView
//		ModelAndView modelAndView = new ModelAndView();
//		// 相当于request的setAttribute方法
//		modelAndView.addObject("itemsList",itemsList);
//		// 指定视图
//		modelAndView.setViewName("/WEB-INF/jsp/items/itemsList.jsp");
//		return modelAndView;
//	}
}
