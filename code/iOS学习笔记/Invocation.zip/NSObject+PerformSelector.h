//
//  NSObject+PerformSelector.h
//  单例模式
//
//  Created by 陈平 on 2017/2/27.
//  Copyright © 2017年 陈平. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (PerformSelector)

- (id)performSelector:(SEL)aSelector withObjects:(NSArray*)objects;

@end
