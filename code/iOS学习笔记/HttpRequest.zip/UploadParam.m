//
//  UploadParam.m
//  MultiThread
//
//  Created by 陈平 on 2017/2/27.
//  Copyright © 2017年 陈平. All rights reserved.
//

#import "UploadParam.h"

@implementation UploadParam

@end
